import requests
from requests.auth import HTTPBasicAuth
import json
def get_forecast(api_key, location_key, days=5, language='ru-RU'):
    """
    Получает прогноз погоды на несколько дней для заданной локации.

    api_key: API ключ AccuWeather
    location_key: ключ локации в AccuWeather
    days: количество дней прогноза (например, 3 или 7)
    language: язык ответа

    return: список dict с данными {date, min_temp, max_temp, humidity, wind_speed, precipitation_probability}
    """
    url = f'http://dataservice.accuweather.com/forecasts/v1/daily/{days}day/{location_key}'
    params = {
        'apikey': api_key,
        'language': language,
        'metric': 'true',
        'details': 'true'
    }

    response = requests.get(url, params=params).text
    print(response)
    forecast_data = json.loads(response)['DailyForecasts']

    forecast_list = []
    for day in forecast_data:
        forecast = {
            'date': day['Date'],
            'min_temp': day['Temperature']['Minimum']['Value'],
            'max_temp': day['Temperature']['Maximum']['Value'],
            'humidity': day['Day']['RelativeHumidity'],
            'wind_speed': day['Day']['Wind']['Speed']['Value'],
            'precipitation_probability': day['Day']['PrecipitationProbability']
        }
        forecast_list.append(forecast)

    return forecast_list


def get_conditions_by_key(api_key, location_key, language='ru-RU'):
    """
    Возвращает текущие погодные условия для указанной локации.

    api_key: API ключ AccuWeather
    location_key: ключ локации в AccuWeather
    language: язык ответа

    return: dict - {text_conditions, temperature, humidity, wind_speed, precipitation_probability}
    """

    url = f'http://dataservice.accuweather.com/currentconditions/v1/{location_key}'
    data = {
        'apikey': api_key,
        'language': language,
        'details': 'true'
    }

    current_response = requests.get(url, params=data).text

    # Получаем прогноз на ближайший час для информации о вероятности осадков
    url = f'http://dataservice.accuweather.com/forecasts/v1/hourly/1hour/{location_key}'
    data = {
        'apikey': api_key,
        'language': language,
        'details': 'true',
        'metric': 'true'
    }

    forecast_response = requests.get(url, params=data).text

    print(parse_conditions(current_response, forecast_response))

    return parse_conditions(current_response, forecast_response)


def get_coordinates(api_key, location_key, language='ru-RU'):
    """
    Возвращает координаты для указанной локации.

    api_key: API ключ AccuWeather
    location_key: ключ локации в AccuWeather
    language: язык ответа

    return: tuple (latitude, longitude)
    """

    url = f'http://dataservice.accuweather.com/locations/v1/{location_key}'
    data = {
        'apikey': api_key,
        'language': language,
        'details': 'true'
    }

    coord_response = requests.get(url, params=data).text

    parsed_resp = json.loads(coord_response)

    return (parsed_resp['GeoPosition']['Latitude'], parsed_resp['GeoPosition']['Longitude'])


def parse_conditions(current_response, forecast_response):
    """
    Извлекает основные погодные условия из ответов API.

    current_response: ответ API по текущим состояниям погоды
    forecast_response: ответ API по прогнозу

    return: dict - {text_conditions, temperature, humidity, wind_speed, precipitation_probability}
    """

    print(current_response)

    current_json_response = json.loads(current_response)[0]
    forecast_json_response = json.loads(forecast_response)[0]

    response = dict()

    response['text_conditions'] = current_json_response['WeatherText']
    response['temperature'] = current_json_response['Temperature']['Metric']['Value']
    response['humidity'] = current_json_response['RelativeHumidity']
    response['wind_speed'] = current_json_response['Wind']['Speed']['Metric']['Value']
    response['precipitation_probability'] = forecast_json_response['PrecipitationProbability']

    return response


def get_location_key_coordinates(api_key, coordinates, language='ru-RU'):
    """
     Возвращает ключ локации для заданных координат.

     api_key: API ключ AccuWeather
     coordinates: координаты в формате кортежа (float, float)
     language: язык ответа

     return: ключ локации (int)
     """

    url = 'http://dataservice.accuweather.com/locations/v1/cities/geoposition/search'
    data = {
        'apikey': api_key,
        'q': ','.join(map(str, coordinates)),
        'language': language
    }

    response = requests.get(url, params=data).text
    json_response = json.loads(response)

    return json_response['Key']


def get_location_key_name(api_key, name, language='ru-RU'):
    """
    Возвращает ключ локации по имени города.

    api_key: API ключ AccuWeather
    name: имя города
    language: язык ответа

    return: ключ локации (int)
    """

    url = 'http://dataservice.accuweather.com/locations/v1/cities/search'
    data = {
        'apikey': api_key,
        'q': name,
        'language': language,
        'alias': 'Always'
    }

    try:
        response = requests.get(url, params=data).text
        json_response = json.loads(response)

        return json_response[0]['Key'], json_response[0]['LocalizedName']
    except KeyError:
        raise KeyError('Город не найден или произошла ошибка на стороне API AccuWeather. Проверьте лимит запросов.')
    except TypeError:
        raise TypeError('Возможно, произошла ошибка на стороне API AccuWeather. Проверьте лимит запросов.')
    except IndexError:
        raise IndexError('Возможно произошла ошибка на стороне API AccuWeather. Проверьте лимит запросов.')
